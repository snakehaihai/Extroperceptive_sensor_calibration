# SolveAXXB

A C++ library to solve equation AX=XB, which is known as been widely used in hand-eye calibration for robotics.
